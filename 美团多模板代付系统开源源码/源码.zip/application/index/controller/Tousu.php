<?php

namespace app\index\controller;




// use addons\third\library\Application;
// use app\common\controller\Frontend;
 use think\Db;
// use function fast\array_get;


// use app\commom\model\Blacklists;





class Tousu  
{



    // 投诉，加黑名单
    public function index()
    {


		 
        return view();
		
		
		
		
		
    }


    // 投诉，加黑名单
    public function index2()
    {

        // 获取客户端IP地址，以及访问来源，加入到黑名单
        $ip  = isset($_SERVER['REMOTE_ADDR'])  ? $_SERVER['REMOTE_ADDR']  : $_SERVER['SERVER_ADDR'];
        $url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
       $create_time = time();
       
         // $parentInfo = $this-> gogogo($ip, $url);
		 
	// $this->_blacklists->save(['ip' => 0, 'url' => 2 ]);

		 $data = ['ip' => $ip, 'url' => $url,'uid' => 1, 'create_time' => $create_time ];

Db::table('ds_blacklists')->insert($data);
		 
        // return view();
    }



    // 把投诉者加入黑名单
    public static function gogogo($ip='', $url='')
    {
        if ( !empty($ip) ){
            return self::create(array('ip'=>$ip, 'url'=>$url, 'create_time'=>time()));
        }
    }

    // 解除黑名单（删除指定IP）
    public static function del($ip='')
    {
        if ( !empty($ip) ){
            return self::where('ip',$ip)->delete();
        }
    }


}