<?php

namespace app\item\controller;

use app\common\model\Blacklists;
use app\common\model\Domains;
use think\Controller;
use think\Request;

class Base extends Controller
{

    public function initialize()
    {

        // 查询客户端IP在不在黑名单里
        $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : $_SERVER['SERVER_ADDR'];
        if ( Blacklists::where('ip', $ip)->find() ){
            $this->redirect(fission('err_url'));die;
        }

        //判断是否只能微信访问
        if (fission('is_wechat') == 1){
            $llq = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger');
            $iPad    = strpos($_SERVER['HTTP_USER_AGENT'], 'iPad');
            $iPhone  = strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone');
            $Android = strpos($_SERVER['HTTP_USER_AGENT'], 'Android');

            //判断浏览器，非微信浏览器报错
            if ($llq==false || ($iPhone==false && $Android==false && $iPad==false)) {
                $this->redirect(fission('err_url'));die;
            }
        }

    }




}
