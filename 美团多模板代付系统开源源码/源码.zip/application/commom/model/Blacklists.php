<?php

namespace app\common\model;




use app\admin\library\Log;



use app\common\controller\Frontend;
use think\Controller;
use think\Db;
use think\Exception;
use think\Request;

use function fast\array_get;






use app\commom\model\base;

use think\Model;

class Blacklists extends Model
{

    // 把投诉者加入黑名单
    public static function gogogo($ip='', $url='')
    {
        if ( !empty($ip) ){
            return self::create(array('ip'=>$ip, 'url'=>$url, 'create_time'=>time()));
        }
    }

    // 解除黑名单（删除指定IP）
    public static function del($ip='')
    {
        if ( !empty($ip) ){
            return self::where('ip',$ip)->delete();
        }
    }





}
