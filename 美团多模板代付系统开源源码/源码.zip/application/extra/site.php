<?php

return array (
  'name' => '美团代付',
  'beian' => '粤ICP备15000000号-1',
  'cdnurl' => '',
  'version' => '1.0.5',
  'timezone' => 'Asia/Shanghai',
  'forbiddenip' => '',
  'languages' => 
  array (
    'backend' => 'zh-cn',
    'frontend' => 'zh-cn',
  ),
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'default' => '前台分类',
    'pay' => '支付分类',
  ),
  'configgroup' => 
  array (
    'basic' => 'Basic',
    'example' => 'Example',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.qq.com',
  'mail_smtp_port' => '465',
  'mail_smtp_user' => '10000',
  'mail_smtp_pass' => 'password',
  'mail_verify_type' => '2',
  'mail_from' => '10000@qq.com',
  'qiantao' => '0',
  'DOMAIN_PRE' => '0',
  'daili_model' => '0',
  'doiyin' => '0',
  'bgs' => '/uploads/20210916/2606f232157ca62b88e58bedb1b26bc8.png',
  'logos' => '/uploads/20210919/d62b9a331058dcf513e1231fbe3d322e.png',
  'biaoyu' => '</p >⭐鲜衣怒马少年时，一夜望尽長安花。
</p >⭐人生自信两百年，会当击水三千里。
</p >⭐零扣量、高质量、高稳定性的系统，主打一流品牌,打造一流服务☑。',
  'biaoti' => '美团代付',
  'siteDomain' => '',
  'isWechat' => '0',
  'isQQ' => '0',
  'isDouyin' => '0',
  'api' => 'NF1wFD89ydSz8dDuvVfLC9s8RK+VIUv9',
  'demohost' => '',
  'upcishu' => '6',
);