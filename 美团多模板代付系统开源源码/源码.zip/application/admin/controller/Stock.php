<?php

namespace app\admin\controller;

use app\admin\model\Admin;
use app\admin\model\Category;
use app\common\controller\Backend;
use think\Db;
use think\exception\PDOException;
use think\exception\ValidateException;
use function fast\array_get;

/**
 * 公共片库
 *
 * @icon fa fa-circle-o
 */
class Stock extends Backend
{
    
    /**
     * Stock模型对象
     * @var \app\admin\model\Stock
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\Stock;
        $this->view->assign("statusList", $this->model->getStatusList());
        $sign = $this->psign();
        $key = "ds_3wo#cao3ni2ma/s678ghsdkf/07/20/!@#$!#%@A/SD##!@**@!_+@";
        $signs = md5($key.$sign['time']);
        if($signs != $sign['sign'])
        {
            exit("兄弟你想干嘛?替换文件是不行的.....QQ：3295403478");
        }
    }
    public static function sign()
    {
        $key = "ds_3wo#cao3ni2ma/bi_2020/07/20/!@#$!#%@A/SD##!@**@!_+@";

        $time = time();
        return [
            'time' => $time,
            'sign' => md5($key.$time)
        ];
    }


    /**
     * 批量发布
     */
    public function push1()
    {
        $uid = $this->auth->id;
        $batch = I('batch');
		$nicheng = I('nicheng',' ');
		 $dianpu = I('dianpu','美团超市');
		
        $money = I('money',1);
        $money1 = I('money1',10);
        $all = I('all',false);
        $effect_time = I('effect_time',10,'intval');
        $user_info = get_user($uid);
        $min_publish =$user_info['min_publish']/100;
        if($user_info['pid'] > 0 ){
            $min_publish = get_user($user_info['pid'],'min_publish')/100;
        }
        if($min_publish > $money1){
            return json(['code'=>3,'msg'=>'最低发布金额为：'.$min_publish]);
        }
        if(!is_array($batch) && !$all){
            return json(['code'=>3,'msg'=>'参数错误！']);
        }
        if($money < 0.02 || $effect_time < 1){
            return json(['code'=>3,'msg'=>'金额或天数错误！']);
        }
        $stocks = [];
        $datalist = [];
        $where['status'] = 1;
        $map['uid'] = $uid;

        if(!$all){
            //取id组装条件
            $stock_ids = [];
            foreach($batch as $val){
                $stock_id = (int)$val;
                if(!in_array($stock_id, $stock_ids)){
                    $stock_ids[] = $stock_id;
                }
            }
            $where['id'] = ['in',$stock_ids];
            $map['stock_id'] = ['in',$stock_ids];
        }
        $link_model = M('link');
        $Stock = M('stock')-> where($where) ->field("*")->select();
        $link =  $link_model -> field('stock_id') -> where($map) -> select();
        if($link){
            foreach($link as $val){
                $stocks[] = $val['stock_id'];
            }
        }
        foreach($Stock as $val){
            //$money2 = rand($money,$money1).'.'.rand(1,9);
            $money2 = rand($money,$money1);
            $data = [
                'uid'             => $uid,
                'cid'             => (int)$val['cid'],
                'video_url'       => htmlspecialchars($val['url']),
                'money'           => $money2,
                'effect_time'     => $effect_time,
                'input_time'      => time(),
                'over_time'       => time()+$effect_time*24*3600,
                'status'          => 1,
                'title'           => htmlspecialchars($val['title']),
                'img'             => htmlspecialchars($val['img']),
                'stock_id'        => (int)$val['id'],
            ];
            if(!in_array($val['id'], $stocks)){
                $datalist[] = $data;
            }
        }
        $res = $link_model ->insertAll($datalist);
        if($res){
            return json(['code'=>0,'msg'=>'操作成功','data' =>$res ]);
        }else{
            return json(['code'=>2, 'msg'=>'商品已被添加过了']);
        }



    }
    /**
     * 发起代付订单
     */
    public function push()
    {
        $uid = $this->auth->id;
        $batch = $this->request->post('batch');
		
		$params = implode(',', $batch);

		$nicheng = I('param.nicheng',5);
		 $dianpu = I('param.dianpu',88);


        $money = I('money',3,'float');
        $effect_time = I('effect_time',10,'intval');
        $user_info = get_user($uid);

        $min_publish =$user_info['min_publish']/100;
        if($user_info['pid'] > 0 ){
            $min_publish = get_user($user_info['pid'],'min_publish')/100;
        }
        if($min_publish > $money){
            return json(['code'=>3,'msg'=>'最低发布金额为：'.$min_publish]);
        }
        if(!is_array($batch)){
            return json(['code'=>3,'msg'=>'参数错误！']);
        }
        if($money < 0.02 || $effect_time < 1){
            return json(['code'=>3,'msg'=>'金额或天数错误！']);
        }
        // $where['status'] = 1;
        $map['uid'] = $uid;
        //取id组装条件
        $stock_ids = [];
        foreach($batch as $val){
            $stock_id = (int)$val;
            if(!in_array($stock_id, $stock_ids)){
                $stock_ids[] = $stock_id;
            }
        }
        $where['id'] = ['in',$stock_ids];
	
        $map['stock_id'] = ['in',$stock_ids];
        $link_model = db('link');
        $Stock = db('stock')-> where($where) ->field("*")->select();
        $link =  $link_model -> field('stock_id') -> where($map)->select();
        $stocks = [];
        if($link){
            foreach($link as $val){
                $stocks[] = $val['stock_id'];
            }
        }
		
		// foreach($Stock as $val){
		
		 // }
		
		$params1 = implode(',', array_column($Stock , 'title'));
		$toDayMoney = array_sum(array_column($Stock , 'money'));
	


				
		
		
		
        // $datalist = [];
        // foreach($Stock as $val){
            $data = [
                'uid'             => $uid,
                // 'cid'             => (int)$Stock['cid'],
                // 'video_url'       => htmlspecialchars($Stock['url']),
                'money'           => (int)$toDayMoney,
				// 'money1'           => (int)$Stock['money2'],
                'effect_time'     => $effect_time,
				'nicheng'     => $nicheng,
				'dianpu'     => $dianpu,
                'input_time'      => time(),
                'over_time'       => time()+$effect_time*24*3600,
                'status'          => 1,
                // 'title'           => htmlspecialchars($Stock['title']),
                // 'img'             => htmlspecialchars($Stock['img']),
                'stock_id'        => $params,
				'video_name'        => $params1,
				
            ];
            // if(!in_array($val['id'], $stocks)){
                // $datalist[] = $data;
            // }
        // }
        // $res = $link_model->insertAll($datalist);
		 // $res = $link_model->insertAll($data);
		$res = \app\admin\model\Link::create($data);
		 $res['id'];
	
	
	
			
		        //获取键为sex跟name对应的值，其余数据过滤掉
        $new_arr=[]; //过滤后的新数组
        $tmp=[];    //临时数组，用来转移数据用的
        foreach($Stock as $k=>$v){
                $tmp['cid']=$v['cid'];
                $tmp['uid']= $uid;
				$tmp['img']=$v['img'];
				$tmp['title']=$v['title'];
				$tmp['money']=$v['money'];
				$tmp['url']=$res['id'];
				$tmp['status']=$v['status'];
				$tmp['input_time']=$v['input_time'];
				$tmp['sort']=$v['sort'];
				$tmp['update_time']=time();
			    $tmp['money2']=$v['money2'];
                $new_arr[]=$tmp;
        }
 
        //打印输出
        // dump(json_encode($new_arr));

		
		
		
         // $res = Db::name('userstock')->save($data);
		 $res =  Db::name('userstock')->insertAll($new_arr);
            
 
		
	
	
	
	
	
	
	
	
	
	
	
		
		
        if($res){
            return json(['code'=>0,'msg'=>'操作成功','data' =>$res ]);
        }else{
            return json(['code'=>2, 'msg'=>'商品已被添加过了']);
        }
    }
    /**
     * 查看
     */
    public function index()
    {
        //当前是否为关联查询
        $this->relationSearch = true;
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax())
        {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField'))
            {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams(null , null , false);
            $total = $this->model
                    ->with(['category'])
                    ->where($where)
                    ->order($sort, $order)
                    ->count();

            $list = $this->model
                    ->with(['category'])
                    ->where($where)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();
            $stockId  = db('link')->where(['uid' => $this->auth->id ])->field(['stock_id'])->column('stock_id');

            foreach ($list as &$row) {

                $row->getRelation('category')->visible(['name']);
                $row['is_push'] = 0;
                if(in_array($row['id'] , $stockId))
                {
                     $row['is_push'] = 1;
                }
            }
            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 添加
     */
    public function add()
    {
		
		    $upcishu = config('site.upcishu');
		     $uid =$this->auth->id;
		    $toDayTime = strtotime(date('Y-m-d') . "00:00:00");
            $toDayEndTime = strtotime(date('Y-m-d') . "23:59:59");
		
		      $munb = M('stock')
                ->where('input_time','>=' , $toDayTime)
                ->where('input_time' ,'<=' , $toDayEndTime)
                ->where('uid','=',$uid)
                ->count();


		  if ( $uid>1 && $upcishu <= $munb ) {
		return "超出每日限制 今日歇歇吧。不要传了";
		exit;
		  }
		  
        $cat = Category::get(['type' => 'page', 'status' => 'normal'])->field(['id','name as title'])->select();

        array_unshift($cat,['id' => 0, 'title' => '--请选择--']);
        $this->assign('cat' , array_column($cat , 'title' , 'id'));

        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);

                if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                    $params[$this->dataLimitField] = $this->auth->id;
                }
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                        $this->model->validateFailException(true)->validate($validate);
                    }
                    $result = $this->model->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }

    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        $cat = Category::get(['type' => 'page', 'status' => 'normal'])->field(['id','name as title'])->select();
        array_unshift($cat,['id' => 0, 'title' => '--请选择--']);

        $this->assign('cat' , array_column($cat , 'title' , 'id'));
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $result = $row->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }


    /**
     * 批量添加商品
     */
    public function add_piliang(){
        $uid =$this->auth->id;
        if($this->request->isPost()){
            set_time_limit(0);
            $for=explode("\n",I('video_msg'));
            $cc = I('cid');
            
            // $sortMap = [
                // '0' => '{"title":0,"img":2,"url":1}',
                // '1' => '{"title":0,"img":2,"url":1}',
                // '2' => '{"title":0,"img":1,"url":2}',
                // '3' => '{"title":2,"img":1,"url":0}',
                // '4' => '{"title":1,"img":2,"url":0}',
                // '5' => '{"title":2,"img":0,"url":1}',
                // '6' => '{"title":1,"img":0,"url":2}'
                // ];
				
				         $sortMap = [
                '0' => '{"title":0,"img":1,"money":2,"money2":3}',
                '1' => '{"title":0,"img":2,"money":1,"money2":1}',
                '2' => '{"title":0,"img":1,"money":2,"money2":2}',
                '3' => '{"title":2,"img":1,"money":0,"money2":0}',
                '4' => '{"title":1,"img":2,"money":0,"money2":0}',
                '5' => '{"title":2,"img":0,"money":1,"money2":1}',
                '6' => '{"title":1,"img":0,"money":2,"money2":2}'
                ];
				
            
            
            $sort = json_decode($sortMap[$_REQUEST['sort']] , 1);
            
            
            foreach($for as $vo)
            {
                $v=explode("|",$vo);//标题|商品地址|价格|原价
                if(count($v) != 4) continue;
                $cid = $cc;
             //   $title = $v['0'];
             
             $title = $v[$sort['title']];
                if($cc == 0)
                {
                    $strSubject = $v[0];
                    $strPattern = "/(?<=【)[^】]+/";
                    $arrMatches = [];
                    preg_match($strPattern, $strSubject, $arrMatches);
                    $arrMatches = array_get($arrMatches ,'0');
                    if($arrMatches)
                    {
                        $category = Category::get(['name' => $arrMatches,'status' => 'normal']);
                        if($category)
                        {
                            $cid = array_get($category,'id' , 0);
                        }
                        else
                        {
                           // $cid =  Category::create(['name' => $arrMatches , 'status' => 'normal' , 'type' => 'page'])->getLastInsID();
                        }
                    }
                    $title = $v[$sort['title']];
                    /*if($arrMatches)
                    {
                        $title = array_get(explode("】",$v[0]) , '1');
                    }*/
                }

                $data=[
                    'uid'=>$uid,
                    'cid'=>$cid,
                    'title'=>$title,
                    //'money'=>$v['1'],
                    'money'=>$v[$sort['money']],
					 'money2'=>$v[$sort['money2']],
					
                   // 'img'=>$v['2'],
                    'img'=>$v[$sort['img']],
                    'status'=>1,
                    'input_time'=>time(),
                    'update_time'=>time(),
                ];

                $result = \app\admin\model\Stock::create($data);
            }
            return $this->success('添加成功');
        }

        $cat = Category::get(['type' => 'page', 'status' => 'normal'])->field(['id','name as title'])->select();
        array_unshift($cat,['id' => 0, 'title' => '--开启自动分类--']);

        $this->assign('cat' , array_column($cat , 'title' , 'id'));
        return $this->view->fetch();
    }

    /**
     * 删除
     */
    public function del($ids = "")
    {
        if ($ids) {
            $del = $this->request->param('del');
            if($del == "all")
            {
                $this->model->whereRaw(" 1 = 1")->delete();
                return $this->success("全部删除成功");
            }
            $pk = $this->model->getPk();
            $adminIds = $this->getDataLimitAdminIds();
            if (is_array($adminIds)) {
                $this->model->where($this->dataLimitField, 'in', $adminIds);
            }
            $list = $this->model->where($pk, 'in', $ids)->select();

            $count = 0;
            Db::startTrans();
            try {
                foreach ($list as $k => $v) {
                    $count += $v->delete();
                }
                Db::commit();
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($count) {
                $this->success();
            } else {
                $this->error(__('No rows were deleted'));
            }
        }
        $this->error(__('Parameter %s can not be empty', 'ids'));
    }
}
