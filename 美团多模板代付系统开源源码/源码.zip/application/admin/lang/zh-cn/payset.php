<?php

return [
    'Uid'         => '用户id',
    'Title'       => '标题',
    'App_id'      => 'app_Id',
    'App_key'     => 'app_key',
    'Pay_channel' => '支付渠道',
    'Status'      => '是否启用',
    'Status 2'    => '禁用',
    'Status 1'    => '正常',
    'Model'       => '标识',
    'Createtime'  => '创建时间'
];
