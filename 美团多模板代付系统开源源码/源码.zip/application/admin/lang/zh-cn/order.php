<?php

return [
    'is_kouliang' => '是否扣量',
    'pid' => '上级代理id',
    'Uid' => '用户id',
    'Des'           => '描述记录',
    'Vid'           => '商品id',
    'Pay_channel'   => '支付渠道',
    'Ip'            => 'ip',
    'Price'         => '金额(元)',
    'Tc_money'      => '总代理提成',
    'Createtime'    => '下单时间',
    'Updatetime'    => '修改时间',
    'Status'        => '支付状态',
    'Status 1'      => '已支付',
    'Status 2'      => '未支付',
    'Pid_top'       => '总代理id',
    'Is_kouliang'   => '是否扣量',
    'Is_kouliang 1' => '不扣量',
    'Is_kouliang 2' => '扣量',
    'Transact'      => '订单号',
    'Is_month'      => '是否包月',
    'Is_month 1'    => '否',
    'Is_month 2'    => '是',
    'Is_date'       => '是否包日',
    'Is_date 1'     => '否',
    'Is_date 2'     => '是'
];
