<?php

return [
    'Id' => '编号',
    'Ip'        => 'ip地址',
    'Url'      => '访问页面',
    'Memo'       => '备注',
    'Create_time' => '创建时间'
];
