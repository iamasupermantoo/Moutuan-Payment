<?php

return [
    'Id'          => 'ID',
    'Cid' => '分类',
    'Img'         => '商品图片',
    'Title'       => '商品名字',
    // 'Url'         => '商品价格',
	 'Money'         => '商品价格',
	 	 'Money2'         => '原价',
    'Status'      => '状态',
    'Status 1'    => '启用',
    'Status 2'    => '禁用',
    'Input_time'  => '添加时间',
    'Sort'        => '排序',
    'Update_time' => '修改时间',
    'Category.name' => '分类',
    'Delete' => '批量删除',
    'Add' => '添加商品',
    'is_push' => '推广状态'

];
