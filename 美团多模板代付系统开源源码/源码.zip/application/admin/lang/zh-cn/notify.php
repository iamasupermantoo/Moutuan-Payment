<?php

return [
    'Id' => '编号',
    'Title' => '标题',
    'Content' => '内容',
    'Createtime' => '创建时间',
    'Is_show'   => '状态',
    'Is_show 1' => '显示',
    'Is_show 2' => '隐藏'
];
