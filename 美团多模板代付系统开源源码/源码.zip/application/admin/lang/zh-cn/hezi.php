<?php

return [
    'Uid'      => '用户id',
    'Video'    => '商品连接',
    'Title'    => '标题',
    'Add_time' => '添加时间',
    'Status'   => '状态',
    'Status 1' => '开启',
    'Status 2' => '关闭'
];
