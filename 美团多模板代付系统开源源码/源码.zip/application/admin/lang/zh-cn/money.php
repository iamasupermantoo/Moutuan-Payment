<?php

return [
    'Id' => '编号',
    'Uid'        => '会员ID',
    'Money'      => '变更积分',
    'Before'     => '变更前积分',
    'After'      => '变更后积分',
    'Memo'       => '备注',
    'Createtime' => '创建时间'
];
