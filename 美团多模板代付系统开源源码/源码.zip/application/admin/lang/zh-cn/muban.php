<?php

return [
    'Title'      => '标题',
    'Muban'      => '模版标识',
    'Status'     => '是否启用',
    'Status 1'   => '启用',
    'Status 0'   => '关闭',
    'Image'      => '封面图',
    'Desc'       => '描述',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间'
];
