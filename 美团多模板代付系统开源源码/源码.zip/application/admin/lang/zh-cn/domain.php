<?php

return [
    'Id'         => 'ID',
    'Domain'     => '域名',
    'Type'       => '类型',
    'Type 1'     => '入口域名',
    'Type 2'     => '落地域名',
    'Type 3'     => '支付域名',
    'Status'     => '状态',
    'Status 1'   => '正常',
    'Status -1'  => '删除',
    'Status 0'   => '屏蔽',
	
	
    'is_bind 0'   => '没绑定',
	'is_bind 1'   => '绑定',
	
	
	
    'Is_bind'    => '是否被用户绑定',
    'Bing_time'  => '被绑定时间',
    'Uid'        => '绑定的用户ID',
    'Createtime' => '创建时间',
    'Updatetime' => '修改时间'
];
