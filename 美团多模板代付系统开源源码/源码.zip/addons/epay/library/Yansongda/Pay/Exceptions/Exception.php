<?php

namespace Yansongda\Pay\Exceptions;

class Exception extends \Exception
{
}
